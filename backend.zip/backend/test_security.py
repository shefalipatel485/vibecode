from app.utils.security import hash_password, verify_password
from app.utils.jwt_handler import create_access_token, verify_access_token

# Password hashing
password = "Test@12345"

hashed_password = hash_password(password)

print("Original Password:", password)
print("Hashed Password:", hashed_password)

# Verify password
print("Password Correct:", verify_password(password, hashed_password))
print("Wrong Password:", verify_password("Wrong@123", hashed_password))

# JWT token
token = create_access_token({
    "sub": "1",
    "role": "customer"
})

print("\nGenerated JWT Token:")
print(token)

# Verify token
decoded = verify_access_token(token)

print("\nDecoded Token:")
print(decoded)