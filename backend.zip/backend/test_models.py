from app.database.connection import Base, engine

# Import all models
from app.models import *

try:
    print("Checking database tables...")

    for table_name in Base.metadata.tables:
        print("Table:", table_name)

    print("\nTotal tables:", len(Base.metadata.tables))

    # Check database connection
    with engine.connect() as connection:
        print("\nDatabase connection successful!")

    print("\nAll models loaded successfully!")

except Exception as e:
    print("Error:", e)