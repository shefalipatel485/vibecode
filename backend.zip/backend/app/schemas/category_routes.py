
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.models.service_category import ServiceCategory
from app.models.user import User

from app.schemas.category_schema import (
    CategoryCreate,
    CategoryUpdate,
    CategoryResponse
)

from app.utils.auth_dependency import require_roles


router = APIRouter(
    prefix="/categories",
    tags=["Service Categories"]
)


# =====================================
# ADD CATEGORY (ADMIN ONLY)
# =====================================

@router.post(
    "/",
    response_model=CategoryResponse,
    status_code=status.HTTP_201_CREATED
)
def create_category(
    category_data: CategoryCreate,
    current_user: User = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):

    existing_category = db.query(ServiceCategory).filter(
        ServiceCategory.category_name == category_data.category_name
    ).first()

    if existing_category:
        raise HTTPException(
            status_code=400,
            detail="Category already exists"
        )

    new_category = ServiceCategory(
        category_name=category_data.category_name,
        description=category_data.description,
        image_url=category_data.image_url
    )

    db.add(new_category)
    db.commit()
    db.refresh(new_category)

    return new_category


# =====================================
# GET ALL ACTIVE CATEGORIES
# =====================================

@router.get(
    "/",
    response_model=list[CategoryResponse]
)
def get_categories(
    db: Session = Depends(get_db)
):

    return db.query(ServiceCategory).filter(
        ServiceCategory.is_active == True
    ).all()


# =====================================
# GET CATEGORY BY ID
# =====================================

@router.get(
    "/{category_id}",
    response_model=CategoryResponse
)
def get_category(
    category_id: int,
    db: Session = Depends(get_db)
):

    category = db.query(ServiceCategory).filter(
        ServiceCategory.id == category_id,
        ServiceCategory.is_active == True
    ).first()

    if not category:
        raise HTTPException(
            status_code=404,
            detail="Category not found"
        )

    return category


# =====================================
# ADMIN: GET ALL CATEGORIES
# Includes inactive categories
# =====================================

@router.get(
    "/admin/all",
    response_model=list[CategoryResponse]
)
def get_all_categories(
    current_user: User = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):

    return db.query(ServiceCategory).all()


# =====================================
# UPDATE CATEGORY (ADMIN ONLY)
# =====================================

@router.put(
    "/{category_id}",
    response_model=CategoryResponse
)
def update_category(
    category_id: int,
    category_data: CategoryUpdate,
    current_user: User = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):

    category = db.query(ServiceCategory).filter(
        ServiceCategory.id == category_id
    ).first()

    if not category:
        raise HTTPException(
            status_code=404,
            detail="Category not found"
        )

    update_data = category_data.model_dump(exclude_unset=True)

    # Check duplicate category name
    new_name = update_data.get("category_name")

    if new_name:
        existing_category = db.query(ServiceCategory).filter(
            ServiceCategory.category_name == new_name,
            ServiceCategory.id != category_id
        ).first()

        if existing_category:
            raise HTTPException(
                status_code=400,
                detail="Category name already exists"
            )

    for field, value in update_data.items():
        setattr(category, field, value)

    db.commit()
    db.refresh(category)

    return category


# =====================================
# DELETE CATEGORY (ADMIN ONLY)
# =====================================

@router.delete("/{category_id}")
def delete_category(
    category_id: int,
    current_user: User = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):

    category = db.query(ServiceCategory).filter(
        ServiceCategory.id == category_id
    ).first()

    if not category:
        raise HTTPException(
            status_code=404,
            detail="Category not found"
        )

    # Prevent deletion if services are linked
    if category.services:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete category because services are linked to it"
        )

    db.delete(category)
    db.commit()

    return {
        "message": "Category deleted successfully"
    }
