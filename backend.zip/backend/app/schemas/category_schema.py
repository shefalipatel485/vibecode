
from pydantic import BaseModel, ConfigDict, Field
from typing import Optional


# Create category
class CategoryCreate(BaseModel):

    category_name: str = Field(min_length=2, max_length=100)
    description: Optional[str] = None
    image_url: Optional[str] = None


# Update category
class CategoryUpdate(BaseModel):

    category_name: Optional[str] = Field(
        default=None, min_length=2, max_length=100
    )
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_active: Optional[bool] = None


# Category response
class CategoryResponse(BaseModel):

    id: int
    category_name: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_active: bool

    model_config = ConfigDict(from_attributes=True)
