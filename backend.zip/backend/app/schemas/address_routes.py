
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.connection import get_db

from app.models.address import Address
from app.models.customer import Customer
from app.models.user import User

from app.schemas.address_schema import (
    AddressCreate,
    AddressUpdate,
    AddressResponse
)

from app.utils.auth_dependency import require_roles


router = APIRouter(
    prefix="/customer/addresses",
    tags=["Customer Address Management"]
)


# =====================================
# HELPER: GET CURRENT CUSTOMER
# =====================================

def get_customer(current_user: User, db: Session):

    customer = db.query(Customer).filter(
        Customer.user_id == current_user.id
    ).first()

    if not customer:
        raise HTTPException(
            status_code=404,
            detail="Customer profile not found"
        )

    return customer


# =====================================
# ADD ADDRESS
# =====================================

@router.post(
    "/",
    response_model=AddressResponse,
    status_code=status.HTTP_201_CREATED
)
def add_address(
    address_data: AddressCreate,
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = get_customer(current_user, db)

    # If this address is default, unset previous default
    if address_data.is_default:
        db.query(Address).filter(
            Address.customer_id == customer.id
        ).update({"is_default": False})

    # If this is the first address, make it default
    address_count = db.query(Address).filter(
        Address.customer_id == customer.id
    ).count()

    new_address = Address(
        customer_id=customer.id,
        address_line=address_data.address_line,
        city=address_data.city,
        state=address_data.state,
        pincode=address_data.pincode,
        is_default=address_data.is_default or address_count == 0
    )

    db.add(new_address)
    db.commit()
    db.refresh(new_address)

    return new_address


# =====================================
# GET ALL CUSTOMER ADDRESSES
# =====================================

@router.get(
    "/",
    response_model=list[AddressResponse]
)
def get_addresses(
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = get_customer(current_user, db)

    return db.query(Address).filter(
        Address.customer_id == customer.id
    ).all()


# =====================================
# GET ADDRESS BY ID
# =====================================

@router.get(
    "/{address_id}",
    response_model=AddressResponse
)
def get_address(
    address_id: int,
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = get_customer(current_user, db)

    address = db.query(Address).filter(
        Address.id == address_id,
        Address.customer_id == customer.id
    ).first()

    if not address:
        raise HTTPException(
            status_code=404,
            detail="Address not found"
        )

    return address


# =====================================
# UPDATE ADDRESS
# =====================================

@router.put(
    "/{address_id}",
    response_model=AddressResponse
)
def update_address(
    address_id: int,
    address_data: AddressUpdate,
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = get_customer(current_user, db)

    address = db.query(Address).filter(
        Address.id == address_id,
        Address.customer_id == customer.id
    ).first()

    if not address:
        raise HTTPException(
            status_code=404,
            detail="Address not found"
        )

    update_data = address_data.model_dump(exclude_unset=True)

    if update_data.get("is_default") is True:
        db.query(Address).filter(
            Address.customer_id == customer.id
        ).update({"is_default": False})

    for field, value in update_data.items():
        setattr(address, field, value)

    db.commit()
    db.refresh(address)

    return address


# =====================================
# DELETE ADDRESS
# =====================================

@router.delete("/{address_id}")
def delete_address(
    address_id: int,
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = get_customer(current_user, db)

    address = db.query(Address).filter(
        Address.id == address_id,
        Address.customer_id == customer.id
    ).first()

    if not address:
        raise HTTPException(
            status_code=404,
            detail="Address not found"
        )

    was_default = address.is_default

    db.delete(address)
    db.flush()

    # Assign default to another address if necessary
    if was_default:
        another_address = db.query(Address).filter(
            Address.customer_id == customer.id
        ).first()

        if another_address:
            another_address.is_default = True

    db.commit()

    return {
        "message": "Address deleted successfully"
    }
