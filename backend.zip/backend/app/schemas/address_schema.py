
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional


# =====================================
# ADD ADDRESS SCHEMA
# =====================================

class AddressCreate(BaseModel):

    address_line: str = Field(min_length=5, max_length=255)
    city: str = Field(min_length=2, max_length=100)
    state: str = Field(min_length=2, max_length=100)
    pincode: str = Field(min_length=6, max_length=10)

    is_default: bool = False


# =====================================
# UPDATE ADDRESS SCHEMA
# =====================================

class AddressUpdate(BaseModel):

    address_line: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    is_default: Optional[bool] = None


# =====================================
# ADDRESS RESPONSE SCHEMA
# =====================================

class AddressResponse(BaseModel):

    id: int
    customer_id: int
    address_line: str
    city: str
    state: str
    pincode: str
    is_default: bool

    model_config = ConfigDict(from_attributes=True)
