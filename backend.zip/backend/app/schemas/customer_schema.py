
from pydantic import BaseModel, ConfigDict
from typing import Optional


# =====================================
# CUSTOMER PROFILE UPDATE SCHEMA
# =====================================

class CustomerProfileUpdate(BaseModel):

    gender: Optional[str] = None
    profile_image: Optional[str] = None


# =====================================
# CUSTOMER PROFILE RESPONSE SCHEMA
# =====================================

class CustomerProfileResponse(BaseModel):

    id: int
    user_id: int
    gender: Optional[str] = None
    profile_image: Optional[str] = None

    full_name: str
    email: str
    mobile: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
