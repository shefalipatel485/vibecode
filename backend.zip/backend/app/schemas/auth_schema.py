
from pydantic import BaseModel, EmailStr, Field
from typing import Literal, Optional


# =====================================
# USER REGISTRATION
# =====================================

class UserRegister(BaseModel):

    full_name: str
    email: EmailStr
    mobile: Optional[str] = None
    password: str = Field(min_length=8)

    role: Literal[
        "customer",
        "provider",
        "technician"
    ]


# =====================================
# SERVICE PROVIDER REGISTRATION
# =====================================

class ProviderRegister(BaseModel):

    full_name: str
    email: EmailStr
    mobile: Optional[str] = None

    password: str = Field(min_length=8)

    business_name: str = Field(min_length=2, max_length=150)

    business_description: Optional[str] = None

    experience_years: int = Field(default=0, ge=0)

    document_url: Optional[str] = None


# =====================================
# USER LOGIN
# =====================================

class UserLogin(BaseModel):

    email: EmailStr
    password: str


# =====================================
# USER RESPONSE
# =====================================

class UserResponse(BaseModel):

    id: int
    full_name: str
    email: EmailStr
    mobile: Optional[str]
    role: str
    is_active: bool

    class Config:
        from_attributes = True


# =====================================
# TOKEN RESPONSE
# =====================================

class TokenResponse(BaseModel):

    access_token: str
    token_type: str
    user: UserResponse

# =====================================
# TECHNICIAN REGISTRATION
# =====================================

class TechnicianRegister(BaseModel):

    full_name: str
    email: EmailStr
    mobile: Optional[str] = None

    password: str = Field(min_length=8)

    provider_id: Optional[int] = None

    specialization: Optional[str] = None
