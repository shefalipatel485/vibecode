
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
import traceback

from app.database.connection import get_db

from app.models.user import User
from app.models.customer import Customer
from app.models.service_provider import ServiceProvider
from app.models.technician import Technician

from app.schemas.auth_schema import (
    UserRegister,
    ProviderRegister,
    TechnicianRegister,
    UserLogin,
    UserResponse,
    TokenResponse
)

from app.utils.security import hash_password, verify_password
from app.utils.jwt_handler import create_access_token


router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)


# ==========================================
# CHECK DUPLICATE EMAIL AND MOBILE
# ==========================================

def check_existing_user(user_data, db):

    existing_user = db.query(User).filter(
        User.email == user_data.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    if user_data.mobile:

        existing_mobile = db.query(User).filter(
            User.mobile == user_data.mobile
        ).first()

        if existing_mobile:
            raise HTTPException(
                status_code=400,
                detail="Mobile number already registered"
            )


# ==========================================
# CUSTOMER REGISTRATION
# ==========================================

@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED
)
def register_customer(
    user_data: UserRegister,
    db: Session = Depends(get_db)
):

    try:

        if user_data.role != "customer":
            raise HTTPException(
                status_code=400,
                detail="Use the appropriate registration endpoint"
            )

        check_existing_user(user_data, db)

        new_user = User(
            full_name=user_data.full_name,
            email=user_data.email,
            mobile=user_data.mobile,
            password_hash=hash_password(user_data.password),
            role="customer"
        )

        db.add(new_user)
        db.flush()

        new_customer = Customer(
            user_id=new_user.id
        )

        db.add(new_customer)

        db.commit()
        db.refresh(new_user)

        return new_user

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        traceback.print_exc()

        raise HTTPException(
            status_code=500,
            detail="Customer registration failed"
        )


# ==========================================
# SERVICE PROVIDER REGISTRATION
# ==========================================

@router.post(
    "/register/provider",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED
)
def register_provider(
    provider_data: ProviderRegister,
    db: Session = Depends(get_db)
):

    try:

        check_existing_user(provider_data, db)

        new_user = User(
            full_name=provider_data.full_name,
            email=provider_data.email,
            mobile=provider_data.mobile,
            password_hash=hash_password(provider_data.password),
            role="provider"
        )

        db.add(new_user)
        db.flush()

        new_provider = ServiceProvider(
            user_id=new_user.id,
            business_name=provider_data.business_name,
            business_description=provider_data.business_description,
            experience_years=provider_data.experience_years,
            document_url=provider_data.document_url,
            verification_status="pending"
        )

        db.add(new_provider)

        db.commit()
        db.refresh(new_user)

        return new_user

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        traceback.print_exc()

        raise HTTPException(
            status_code=500,
            detail="Provider registration failed"
        )


# ==========================================
# TECHNICIAN REGISTRATION
# ==========================================

@router.post(
    "/register/technician",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED
)
def register_technician(
    technician_data: TechnicianRegister,
    db: Session = Depends(get_db)
):

    try:

        check_existing_user(technician_data, db)

        # Validate provider if supplied
        if technician_data.provider_id is not None:

            provider = db.query(ServiceProvider).filter(
                ServiceProvider.id == technician_data.provider_id
            ).first()

            if not provider:
                raise HTTPException(
                    status_code=404,
                    detail="Service provider not found"
                )

        # Create user
        new_user = User(
            full_name=technician_data.full_name,
            email=technician_data.email,
            mobile=technician_data.mobile,
            password_hash=hash_password(technician_data.password),
            role="technician"
        )

        db.add(new_user)
        db.flush()

        # Create technician profile
        new_technician = Technician(
            user_id=new_user.id,
            provider_id=technician_data.provider_id,
            specialization=technician_data.specialization,
            is_available=True
        )

        db.add(new_technician)

        db.commit()
        db.refresh(new_user)

        return new_user

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        traceback.print_exc()

        raise HTTPException(
            status_code=500,
            detail="Technician registration failed"
        )


# ==========================================
# USER LOGIN
# ==========================================

@router.post(
    "/login",
    response_model=TokenResponse
)
def login_user(
    user_data: UserLogin,
    db: Session = Depends(get_db)
):

    user = db.query(User).filter(
        User.email == user_data.email
    ).first()

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    if not verify_password(
        user_data.password,
        user.password_hash
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    if not user.is_active:
        raise HTTPException(
            status_code=403,
            detail="Your account is inactive"
        )

    access_token = create_access_token(
        data={
            "sub": str(user.id),
            "role": user.role
        }
    )

    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }
