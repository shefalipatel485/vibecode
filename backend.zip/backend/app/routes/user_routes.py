
from fastapi import APIRouter, Depends

from app.models.user import User
from app.utils.auth_dependency import get_current_user, require_roles

router = APIRouter(
    prefix="/users",
    tags=["User Management"]
)


# =====================================
# CURRENT USER PROFILE
# =====================================

@router.get("/me")
def get_my_profile(
    current_user: User = Depends(get_current_user)
):
    return {
        "message": "User profile fetched successfully",
        "id": current_user.id,
        "full_name": current_user.full_name,
        "email": current_user.email,
        "mobile": current_user.mobile,
        "role": current_user.role
    }


# =====================================
# ADMIN ONLY API
# =====================================

@router.get("/admin")
def admin_dashboard(
    current_user: User = Depends(require_roles("admin"))
):
    return {
        "message": "Welcome to Admin Dashboard",
        "admin_name": current_user.full_name,
        "role": current_user.role
    }


# =====================================
# CUSTOMER ONLY API
# =====================================

@router.get("/customer")
def customer_dashboard(
    current_user: User = Depends(require_roles("customer"))
):
    return {
        "message": "Welcome to Customer Dashboard",
        "customer_name": current_user.full_name
    }


# =====================================
# PROVIDER ONLY API
# =====================================

@router.get("/provider")
def provider_dashboard(
    current_user: User = Depends(require_roles("provider"))
):
    return {
        "message": "Welcome to Provider Dashboard",
        "provider_name": current_user.full_name
    }


# =====================================
# TECHNICIAN ONLY API
# =====================================

@router.get("/technician")
def technician_dashboard(
    current_user: User = Depends(require_roles("technician"))
):
    return {
        "message": "Welcome to Technician Dashboard",
        "technician_name": current_user.full_name
    }
