
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.models.customer import Customer
from app.models.user import User

from app.schemas.customer_schema import (
    CustomerProfileUpdate,
    CustomerProfileResponse
)

from app.utils.auth_dependency import require_roles


router = APIRouter(
    prefix="/customer",
    tags=["Customer Profile"]
)


# =====================================
# GET CUSTOMER PROFILE
# =====================================

@router.get("/profile", response_model=CustomerProfileResponse)
def get_customer_profile(
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = db.query(Customer).filter(
        Customer.user_id == current_user.id
    ).first()

    if not customer:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Customer profile not found"
        )

    return {
        "id": customer.id,
        "user_id": customer.user_id,
        "gender": customer.gender,
        "profile_image": customer.profile_image,
        "full_name": current_user.full_name,
        "email": current_user.email,
        "mobile": current_user.mobile
    }


# =====================================
# UPDATE CUSTOMER PROFILE
# =====================================

@router.put("/profile", response_model=CustomerProfileResponse)
def update_customer_profile(
    profile_data: CustomerProfileUpdate,
    current_user: User = Depends(require_roles("customer")),
    db: Session = Depends(get_db)
):

    customer = db.query(Customer).filter(
        Customer.user_id == current_user.id
    ).first()

    if not customer:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Customer profile not found"
        )

    # Update only the fields provided
    update_data = profile_data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        setattr(customer, field, value)

    db.commit()
    db.refresh(customer)

    return {
        "id": customer.id,
        "user_id": customer.user_id,
        "gender": customer.gender,
        "profile_image": customer.profile_image,
        "full_name": current_user.full_name,
        "email": current_user.email,
        "mobile": current_user.mobile
    }
