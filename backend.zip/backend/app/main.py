
from fastapi import FastAPI

# =====================================
# IMPORT ROUTERS
# =====================================

from app.routes.auth_routes import router as auth_router
from app.routes.user_routes import router as user_router
from app.routes.customer_routes import router as customer_router
from app.routes.address_routes import router as address_router
from app.routes.category_routes import router as category_router


# =====================================
# CREATE FASTAPI APPLICATION
# =====================================

app = FastAPI(
    title="HomeServe API",
    description="Home Services Booking SaaS Platform",
    version="1.0.0"
)


# =====================================
# REGISTER ALL ROUTERS
# =====================================

app.include_router(auth_router)
app.include_router(user_router)
app.include_router(customer_router)
app.include_router(address_router)
app.include_router(category_router)


# =====================================
# HOME API
# =====================================

@app.get("/")
def home():

    return {
        "message": "Welcome to HomeServe API",
        "status": "Application running successfully"
    }


# =====================================
# HEALTH CHECK API
# =====================================

@app.get("/health")
def health_check():

    return {
        "status": "healthy",
        "message": "HomeServe API is working"
    }
