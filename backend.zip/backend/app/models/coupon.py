from sqlalchemy import Column, Integer, String, Numeric, Date, Boolean
from app.database.connection import Base


class Coupon(Base):
    __tablename__ = "coupons"

    id = Column(Integer, primary_key=True, index=True)
    coupon_code = Column(String(50), unique=True, nullable=False)
    discount_type = Column(
        String(20), nullable=False
    )  # percentage or fixed
    discount_value = Column(Numeric(10, 2), nullable=False)
    minimum_order_amount = Column(Numeric(10, 2), default=0)
    maximum_discount = Column(Numeric(10, 2), nullable=True)
    start_date = Column(Date, nullable=False)
    expiry_date = Column(Date, nullable=False)
    usage_limit = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)