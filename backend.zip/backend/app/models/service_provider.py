
from sqlalchemy import Column, Integer, String, ForeignKey, Enum, Text
from sqlalchemy.orm import relationship

from app.database.connection import Base


class ServiceProvider(Base):

    __tablename__ = "service_providers"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        unique=True,
        nullable=False
    )

    business_name = Column(String(150), nullable=False)

    business_description = Column(Text, nullable=True)

    experience_years = Column(Integer, default=0)

    verification_status = Column(
        Enum("pending", "approved", "rejected", name="verification_status"),
        default="pending"
    )

    document_url = Column(String(255), nullable=True)

    user = relationship("User", back_populates="provider")
