
from sqlalchemy import (
    Column, Integer, String, ForeignKey,
    Boolean, Text, Numeric
)
from sqlalchemy.orm import relationship

from app.database.connection import Base


class Service(Base):

    __tablename__ = "services"

    id = Column(Integer, primary_key=True, index=True)

    category_id = Column(
        Integer,
        ForeignKey("service_categories.id"),
        nullable=False
    )

    service_name = Column(String(150), nullable=False)

    description = Column(Text, nullable=True)

    price = Column(Numeric(10, 2), nullable=False)

    duration_minutes = Column(Integer, nullable=False)

    image_url = Column(String(255), nullable=True)

    is_active = Column(Boolean, default=True)

    category = relationship(
        "ServiceCategory",
        back_populates="services"
    )

    provider_services = relationship(
        "ProviderService",
        back_populates="service"
    )
