
from sqlalchemy import Column, Integer, String, Boolean, Text
from sqlalchemy.orm import relationship

from app.database.connection import Base


class ServiceCategory(Base):

    __tablename__ = "service_categories"

    id = Column(Integer, primary_key=True, index=True)

    category_name = Column(String(100), unique=True, nullable=False)

    description = Column(Text, nullable=True)

    image_url = Column(String(255), nullable=True)

    is_active = Column(Boolean, default=True)

    services = relationship(
        "Service",
        back_populates="category"
    )
