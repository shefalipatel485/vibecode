from sqlalchemy import Column, Integer, ForeignKey, Text, DateTime, func
from sqlalchemy.orm import relationship
from app.database.connection import Base


class Review(Base):
    __tablename__ = "reviews"

    id = Column(Integer, primary_key=True, index=True)

    booking_id = Column(
        Integer, ForeignKey("bookings.id"), nullable=False
    )

    customer_id = Column(
        Integer, ForeignKey("customers.id"), nullable=False
    )

    provider_id = Column(
        Integer, ForeignKey("service_providers.id"), nullable=False
    )

    rating = Column(Integer, nullable=False)
    comment = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    booking = relationship("Booking")
    customer = relationship("Customer")
    provider = relationship("ServiceProvider")