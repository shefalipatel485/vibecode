from sqlalchemy import (
    Column, Integer, ForeignKey, String,
    Numeric, DateTime, Enum, func
)
from sqlalchemy.orm import relationship
from app.database.connection import Base


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)

    booking_id = Column(
        Integer,
        ForeignKey("bookings.id"),
        nullable=False
    )

    payment_method = Column(
        Enum("cash", "online", name="payment_method"),
        nullable=False
    )

    transaction_id = Column(String(150), nullable=True)

    amount = Column(Numeric(10, 2), nullable=False)

    payment_status = Column(
        Enum(
            "pending", "success", "failed", "refunded",
            name="payment_status"
        ),
        default="pending"
    )

    paid_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    booking = relationship("Booking")