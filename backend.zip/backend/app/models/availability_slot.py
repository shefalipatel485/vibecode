
from sqlalchemy import (
    Column, Integer, ForeignKey,
    Time, Boolean, String
)
from sqlalchemy.orm import relationship

from app.database.connection import Base


class AvailabilitySlot(Base):

    __tablename__ = "availability_slots"

    id = Column(Integer, primary_key=True, index=True)

    provider_id = Column(
        Integer,
        ForeignKey("service_providers.id"),
        nullable=False
    )

    day_of_week = Column(String(15), nullable=False)

    start_time = Column(Time, nullable=False)

    end_time = Column(Time, nullable=False)

    is_available = Column(Boolean, default=True)

    provider = relationship("ServiceProvider")
