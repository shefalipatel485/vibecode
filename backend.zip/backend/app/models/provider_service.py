
from sqlalchemy import (
    Column, Integer, ForeignKey, Numeric,
    Boolean, UniqueConstraint
)
from sqlalchemy.orm import relationship

from app.database.connection import Base


class ProviderService(Base):

    __tablename__ = "provider_services"

    __table_args__ = (
        UniqueConstraint(
            "provider_id",
            "service_id",
            name="unique_provider_service"
        ),
    )

    id = Column(Integer, primary_key=True, index=True)

    provider_id = Column(
        Integer,
        ForeignKey("service_providers.id"),
        nullable=False
    )

    service_id = Column(
        Integer,
        ForeignKey("services.id"),
        nullable=False
    )

    service_price = Column(Numeric(10, 2), nullable=False)

    is_available = Column(Boolean, default=True)

    provider = relationship("ServiceProvider")

    service = relationship(
        "Service",
        back_populates="provider_services"
    )
