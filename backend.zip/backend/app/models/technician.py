
from sqlalchemy import Column, Integer, String, ForeignKey, Boolean
from sqlalchemy.orm import relationship

from app.database.connection import Base


class Technician(Base):

    __tablename__ = "technicians"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        unique=True,
        nullable=False
    )

    provider_id = Column(
        Integer,
        ForeignKey("service_providers.id"),
        nullable=True
    )

    specialization = Column(String(100), nullable=True)

    is_available = Column(Boolean, default=True)

    user = relationship("User", back_populates="technician")

    provider = relationship("ServiceProvider")
