from sqlalchemy import Column, Integer, ForeignKey, DateTime, Enum, func
from sqlalchemy.orm import relationship
from app.database.connection import Base

class BookingAssignment(Base):
    __tablename__ = "booking_assignments"

    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    technician_id = Column(Integer, ForeignKey("technicians.id"), nullable=False)

    assigned_at = Column(DateTime, server_default=func.now())

    status = Column(
        Enum(
            "assigned", "accepted", "rejected",
            "completed", name="assignment_status"
        ),
        default="assigned"
    )

    booking = relationship("Booking", back_populates="assignments")
    technician = relationship("Technician")