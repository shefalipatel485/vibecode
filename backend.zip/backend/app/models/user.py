
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, Enum, func
)
from sqlalchemy.orm import relationship

from app.database.connection import Base


class User(Base):

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)

    full_name = Column(String(100), nullable=False)

    email = Column(String(150), unique=True, nullable=False, index=True)

    mobile = Column(String(15), unique=True, nullable=True)

    password_hash = Column(String(255), nullable=False)

    role = Column(
        Enum("admin", "customer", "provider", "technician", name="user_role"),
        nullable=False
    )

    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime, server_default=func.now())

    updated_at = Column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now()
    )

    # One-to-one relationships
    customer = relationship("Customer", back_populates="user", uselist=False)

    provider = relationship(
        "ServiceProvider",
        back_populates="user",
        uselist=False
    )

    technician = relationship(
        "Technician",
        back_populates="user",
        uselist=False
    )
