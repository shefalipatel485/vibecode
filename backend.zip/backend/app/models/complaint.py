from sqlalchemy import Column, Integer, ForeignKey, Text, DateTime, Enum, func
from sqlalchemy.orm import relationship
from app.database.connection import Base
from sqlalchemy import Column, Integer, ForeignKey, String, Text, DateTime, Enum, func

class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(Integer, primary_key=True, index=True)

    booking_id = Column(
        Integer, ForeignKey("bookings.id"), nullable=False
    )

    customer_id = Column(
        Integer, ForeignKey("customers.id"), nullable=False
    )

    subject = Column(String(150), nullable=False)
    description = Column(Text, nullable=False)

    status = Column(
        Enum(
            "open", "in_progress", "resolved", "closed",
            name="complaint_status"
        ),
        default="open"
    )

    created_at = Column(DateTime, server_default=func.now())

    booking = relationship("Booking")
    customer = relationship("Customer")