from sqlalchemy import (
    Column, Integer, String, ForeignKey,
    Date, Time, DateTime, Numeric, Text, Enum, func
)
from sqlalchemy.orm import relationship
from app.database.connection import Base

class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False)
    service_id = Column(Integer, ForeignKey("services.id"), nullable=False)
    address_id = Column(Integer, ForeignKey("addresses.id"), nullable=False)

    booking_date = Column(Date, nullable=False)
    booking_time = Column(Time, nullable=False)

    total_amount = Column(Numeric(10, 2), nullable=False)

    status = Column(
        Enum(
            "pending", "confirmed", "assigned",
            "in_progress", "completed", "cancelled",
            name="booking_status"
        ),
        default="pending"
    )

    customer_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    customer = relationship("Customer")
    service = relationship("Service")
    address = relationship("Address")
    assignments = relationship("BookingAssignment", back_populates="booking")