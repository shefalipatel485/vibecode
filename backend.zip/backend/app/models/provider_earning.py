from sqlalchemy import Column, Integer, ForeignKey, Numeric, DateTime, Enum, func
from sqlalchemy.orm import relationship
from app.database.connection import Base


class ProviderEarning(Base):
    __tablename__ = "provider_earnings"

    id = Column(Integer, primary_key=True, index=True)

    provider_id = Column(
        Integer, ForeignKey("service_providers.id"), nullable=False
    )

    booking_id = Column(
        Integer, ForeignKey("bookings.id"), nullable=False
    )

    booking_amount = Column(Numeric(10, 2), nullable=False)
    platform_commission = Column(Numeric(10, 2), default=0)
    provider_amount = Column(Numeric(10, 2), nullable=False)

    payout_status = Column(
        Enum(
            "pending", "paid", "failed",
            name="payout_status"
        ),
        default="pending"
    )

    created_at = Column(DateTime, server_default=func.now())

    provider = relationship("ServiceProvider")
    booking = relationship("Booking")