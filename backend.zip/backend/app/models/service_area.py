
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from app.database.connection import Base


class ServiceArea(Base):

    __tablename__ = "service_areas"

    id = Column(Integer, primary_key=True, index=True)

    provider_id = Column(
        Integer,
        ForeignKey("service_providers.id"),
        nullable=False
    )

    city = Column(String(100), nullable=False)

    area_name = Column(String(150), nullable=False)

    pincode = Column(String(10), nullable=False)

    provider = relationship("ServiceProvider")
