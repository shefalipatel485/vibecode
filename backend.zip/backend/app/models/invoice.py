from sqlalchemy import (
    Column, Integer, ForeignKey, String,
    Numeric, DateTime, func
)
from sqlalchemy.orm import relationship
from app.database.connection import Base


class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(Integer, primary_key=True, index=True)

    booking_id = Column(
        Integer,
        ForeignKey("bookings.id"),
        unique=True,
        nullable=False
    )

    invoice_number = Column(
        String(50),
        unique=True,
        nullable=False
    )

    subtotal = Column(Numeric(10, 2), nullable=False)
    tax_amount = Column(Numeric(10, 2), default=0)
    discount_amount = Column(Numeric(10, 2), default=0)
    total_amount = Column(Numeric(10, 2), nullable=False)

    invoice_date = Column(DateTime, server_default=func.now())

    pdf_url = Column(String(255), nullable=True)

    booking = relationship("Booking")