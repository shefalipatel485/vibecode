from app.schemas import (
    UserRegister,
    UserLogin,
    UserResponse,
    TokenResponse
)

print("Authentication schemas imported successfully!")