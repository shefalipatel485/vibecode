from app.models.user import User

print("User model imported successfully!")
print("Table name:", User.__tablename__)