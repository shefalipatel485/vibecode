
from app.database.connection import Base, engine

from app.models import (
    User, Customer, ServiceProvider, Technician,
    ServiceCategory, Service, ProviderService,
    ServiceArea, AvailabilitySlot,
    Address, Booking, BookingAssignment, BookingImage,
    Payment, Invoice,
    Coupon, Review, Complaint, Notification, ProviderEarning

)

Base.metadata.create_all(bind=engine)

print("All tables created successfully!")
